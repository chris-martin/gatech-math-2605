package edu.gatech.gth773s.math;

public class DimensionMismatchException extends IllegalArgumentException {
	
	public DimensionMismatchException(String message) {
		super(message);
	}
	
}
