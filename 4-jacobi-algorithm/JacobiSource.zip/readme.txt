Jacobi Algorithm
--------------------------------------------------------------------------------------

Compilation:
     javac *.java
Running:
     java JacobiApplication

Source zip package includes:
   - All source .java files for the Jacobi Algorithm program
   - The JacobiApplication class, for launching the program as a standalone
     application instead of an an applet
   - The compiled functionParser library

Libraries used:
   - functionParser .................................................. Eric Carlen
     http://www.math.gatech.edu/%7Ecarlen/applets/docs/Package-functionParser.html